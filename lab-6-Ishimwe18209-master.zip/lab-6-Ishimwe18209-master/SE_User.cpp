#include "SE-Lab3.h"
#include "SE_User.h"
#include "crossplatformhooks.h"
#include "SE_FilesLogger.h"
#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include <filesystem>


using namespace std;
SE_User::SE_User(string users, string pass)
{
	//default constructor
	username = users;
	password = pass;
}

SE_User::SE_User()
{
	username = "user03";
	password = "password01";
}

SE_User::SE_User(char* username, char* pass)
{
}

string SE_User::listUsers()
{
	return string();
}

int SE_User::saveUser(char* prefix_to_messagedir)
{
	int val = mkdir(prefix_to_messagedir, 0700);
	int val2 = mkdir(path, 0700);

	if (!val || val2)
	{
		logError("Directory has been created");
		return 0;
	}
	else
	{
		logError("Directory unable to be created");
		return -1;
	}
}
void SE_User::saveusername(string susername, string scredentials)
{
	DIR* dir;
	dir = opendir(".");
}

void SE_User::createUser(char* prefix_to_messagedir)
{
}

void SE_User::createusername(string cusername)
{
	username = cusername;
	int test = 0;
	DIR* dir;
	dir = opendir("list_username");
	struct dirent* entry;
	errno = 0;
	while ((entry = readdir(dir)) != NULL)
	{
		cout << entry->d_name << endl;
		if (entry->d_name == username)
		{
			cout << username << "Location exist." << endl;
			test = 1;
		}
	}
	closedir(dir);

	dir = opendir(".");
	errno = 0;
	while ((entry = readdir(dir)) != NULL)
	{
		if (entry->d_name == "directmessage")
		{
			test = 1;
		}
	}
	if (test == 1)
	{
		cout << "failed to create user" << endl;
	}
	else
	{
		cout << "User has been created" << endl;
	}
}

int SE_User::loadUser(char* prefix_to_messagesdir)
{
	return 0;
}

string SE_User::listUsers()
{
	string luser;
	DIR* dir;
	dir = opendir(".");
	string existusers;
	struct dirent* entry;
	errno = 0;
	while ((entry = readdir(dir)) != NULL)
	{
		cout << entry->d_name << endl;
		if (luser == entry->d_name)
		{
			existusers = entry->d_name;
		}
	}
	return existusers;
}

void SE_User::setPassword(string password)
{
}

int SE_User::changePassword(char* oldpw, char* newpw)
{
	const char* validate = oldpass;
	const char* validate1 = oldpw;

	if (strcmp(validate, validate1) == 0)
	{
		oldpass = newpw;
		char output[128];
		sprintf(output, "%s %s", "Password is changed to", newpw);
		LogError(output);
		return 0;
	}
	else
	{
		logError("Password does not match");
		return -1;
	}
}

int SE_User::setPassword(char* newpw)
{
	char* newpass = newpw;
	if (oldpass)
	{
		oldpass = newpw;
		char output[128];
		sprintf(output, "%s %s", "Password is set: ", newpw);
		logError(output);
		return 0;
	}
	else
	{
		logError("Password is set and need to be changed");
		return -1;
	}
}

int SE_User::aunthenticate(const char* pw)
{
	const char* validate = oldpass;
	if (strcmp(pw, validate) == 0)
	{
		logError("it Aunthenticated");
		return 0;
	}
	else
	{
		logError("it did not aunthenticate");
		return -1;
	}
}
int SE_User::loadUser(char* prefix_to_messagesdir)
{
	if (username)
	{
		struct stat dirstats;
		int staterr = 0;
		staterr = stat(path, &dirstats);
		if (!staterr)
		{
			ofstream UserFile(char* preprefix_to_messagesdir);
			logError("The file of the user is open");
			return 0;
		}
		else
			logError("User directory is not found");
	}
else
{
logError("there is nothing for username");
return -2;
}

	int SE_User::logError(char* message);
{
	cout << message << endl;
	return 0;
}
