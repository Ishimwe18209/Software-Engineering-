#include "crossplatformhooks.h"
#include "SE_FilesLogger.h"
#include <string>
#include <vector>
#include <time.h>
#include <fstream>

#pragma once

using namespace std;
class SE_User
{
public:

	char username[64];
	char prefixmsgdir[64];
	char* oldpass;
	char path[64];
	char accessLogFile[256];
	bool fail;

	//default constructor
	string username;
	string password;
	SE_User(string users, string pass);
	SE_User();
	SE_User(char* username, char* pass);
	string listUsers();
	void setPassword(string password);
	int setPassword(char* password);
	int saveUser(char* prefix_to_messagedir);
	void saveusername(string susername, string scredentials);
	void createUser(char* prefix_to_messagedir);
	void createusername(string cusername);
	int loadUser(char* prefix_to_messagesdir);
	int changePassword(char* oldpw, char* newpw);
	int authenticate(const char* pw);
	int logError(char* message);
};