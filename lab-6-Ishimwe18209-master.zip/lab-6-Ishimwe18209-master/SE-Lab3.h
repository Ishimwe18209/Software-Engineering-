﻿// CMakeProject2.h : Include file for standard system include files,
// or project specific include files.

#include <iostream>

// TODO: Reference additional headers your program requires here.

//TODO: getNum() function returns a double value
double getNum();

//TODO: getIntNum() function returns an integer value, and leverage getNum() to get a double
int getIntNum();

//TODO: getPosNum() function returns an integer value, and leverage getNum() to get a double
int getPosNum();