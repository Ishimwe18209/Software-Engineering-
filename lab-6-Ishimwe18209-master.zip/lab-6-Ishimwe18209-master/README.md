# Software Engineering Spring 2021 - Lab 6

This lab will build a class to represent a user in the messaging system. Throughout a user
"session" (which we will define in a following lab), expect to instantiate a user object
to represent the user currently sitting at the keyboard. 

This is a 20pt lab that will take place over two weeks. Plan to
complete 10pts (or more) worth of work this week and the remainder for
the following week. We will be grading this lab in two increments. You
may select whichever 10pts make the most sense to you.This week will
focus on the following areas of software development:

* Data Persistance via file I/O
* Authentication
* Three

## Lab Setup

1. Import Lab 4 sources and CMake files to get started.
2. Copy your Lab 3 input validation .cpp and .h files into this
   repository and integrate them into the build as well. You may
   include it as a simple C library or convert it to a C++ class if
   you prefer. Do not include the Kinetic Energy and Present Value
   functions.
3. We have consolidated the cross-platform header hooks into a separate
   header file called "crossplatformhooks.h". You should #include this
   in your own .h or .cpp files that need dirent, stat, or DELIM.
   You may use dirent OR filesystem API's to read directory objects/entries.
   dirent is POSIX compliant, but not included in Windows, so we are providing
   an implementation as part of this template.

## Requirements

 1. Users will be identified by their \"short name\", which will be stored
	as a member field of the class.

 2. Each user\'s messages will be stored in a subdirectory named
    their shortname via the FilesLogger class.

 3. Shortname must be filesystem-safe! No special characters, no
    spaces. Use input validation. You will have to add another data
	validation method to your library. (via input validation)

 4. A password field must be supported by the user class. This may be unencrypted
	(bad but easy), two-way encrypted (an internal key built-in to
	the compiled software - weak, but better), or one-way encrypted to a hash (best).

 5. The user object will be stored in the filesystem as a file so that it
	is persistent from one run of the program to the next, inside the directory
	named after the user. You may name the user object file whatever
	you want. It can be "userobj" for all users, for instance, or
	you can also name it after the user (like it's enclosing
	directory). As it will be your own format, you may invent an
	extension for your file format, as long as it doesn't clash with
	an existing common extension. Or re-use an appropriate extension
	such as .txt, .yaml, .xml or whatever fits. You may store the important
	user fields in plaintext or binary. Write the fields in a way that allows
	you to read them back in.

 6. Return values from class method calls should be an object pointer
	or NULL when appropriate. OR 0 for success, negative integers for
	various types of failures when appropriate. You get to define this
	API, as you will be its primary user. However, keep in mind that
	one of your collegues may have to write their own code using your
	classes in the future. You may also use try/catch constructs to throw
	errors if you prefer, but be consistent.

## Graded Items (specific details)

Outline of API
Several methods must be supported. Some suggestions of input parameters
are provided. However, you are free to adjust input parameters to suit your
API design. You may overload methods to handle several arguments if desired.

 0. Class shall be named \"SE_User\".

 1. constructor with username (validate input, see below) **[2 points]**

 2. constuctor without username **[2 points]**

 3. listUserNames() - returns names of known users by querying the
    filesystem for existing user directories with user object files
    **[2 points]**

 4. createUser() - succeeds if new user message directory
            AND user's disk file does not exist, and ONLY IF \"newname\"
            passes input validation. Method may take a validated
			string argument OR use the username value set by the
			constructor. Or BOTH (called "overloading"). Does NOT
			modify the filesysem (see saveUser() below) **[2 points]**

 5. saveUser() - writes user info to disk. Creates directory if
            necessary. When you have this working, remove user-dir
			creation from your Logger class if you implemented it
			there. This will prevent storing of messages sent to
			non-existant users. **[2 points]**

 6. setPassword(newpw) - sets new password if no password is set
            yet **[2 points]**

 7. changePassword(oldpw,newpw) - changes password to newpw if
            oldpw matches existing password (calls authenticate() below)
			**[2 points]**

 8. authenticate(pw) - authenticates a user with pw.
		Validates the supplied password argument against the password
		stored on the user object (via encryption or hash if you have
		chosent to do so). Returns success or faiure. **[2 points]**

 9. loadUser() - loads the file from disk if username has already
	been set on the object, if it exists in the filesystem. **[2 points]**
	loadUser(username) loads the specified user file from disk, if it
	exists in the filesystem.


 10. Any errors encountered by main should be logged using the new
     logError() method. If the logError() method fails, write the error
     message to the console. Also log: successful new user creation,
	 successful password change, successful authentication, unsucessful
	 authentication. **[2 points]**

* Extend your main() program test suite to instantiate your class and
  test the methods with various inputs to demonstrate your class
  works. You may find that you wish to break out your growing suite of
  tests into functions within your main.cpp file OR into a separate
  .cpp for tests! Think about that... Eventually main() will do
  actual work and not just testing, but you will want to keep your
  tests available for development and regression-prevention.

**References**

-   http://cplusplus.com

-   <https://www.cplusplus.com/reference/array/array/>

-   Accessing Directories: https://www.gnu.org/software/libc/manual/html_node/File-System-Interface.html
-   Dirent API specifically: https://www.gnu.org/software/libc/manual/html_node/Accessing-Directories.html
