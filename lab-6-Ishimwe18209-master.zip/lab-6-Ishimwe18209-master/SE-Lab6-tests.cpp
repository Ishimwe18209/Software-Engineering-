/* Test wrapper w/ main for logging files in Lab4 */
#include "SE-Lab3.h"
#include "SE_User.h"
#include "SE_FilesLogger.h"
#include "crossplatformhooks.h"
#include <iostream>


#define SUCCESS  0
#define NOARGS  -1
#define BADSTAT -2

using namespace std;

int main(int argc, char** argv) {

    char* prefixdir = NULL;
    struct stat dirstats;
    int staterr = 0;


    /* Data directory from very simplistic commandline argument, if given */
    if (argc > 1) {

        prefixdir = argv[1];
        staterr = stat(prefixdir, &dirstats); // If we can stat it, it exists

        if (staterr) { // stat returns 0 on success, a variety of ints on failure
            printf("stat() of directory %s failed with exit code: %d\n",
                prefixdir, staterr);
            return(BADSTAT);
        }

    }
    else { // no commandline args given
        printf("A data directory path argument is required.\n");
        return(NOARGS);
    } // end directory arg validation

    SE_User user03("vivine");
    char* perfixmsgdirec = "build/message";
    user03.createUser(perfixmsgdirec);
    user03.saveUser(perfixmsgdirec);
    user03.listUsers();

    char* password = "Lot";
    user03.setPassword(password);
    user03.authenticate(password);
    char* pw = "Lot";
    user03.changePassword(pw, "None");
    user03.loadUser(perfixmsgdirec);
    return 0;

   
 