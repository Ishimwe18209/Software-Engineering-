#pragma once
//#include <filesystem.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


#ifdef __linux__
#define DIRSEP '/'
#include <sys/stat.h>
#endif

#ifdef _WIN32
#define DIRSEP '\\'
#include <direct.h>
#endif

#ifdef __APPLE__
#define DIRSEP '/'
#include <sys/stat.h>
#endif


/****************************************
 * Class specification, includes method prototypes
 * and public/private member variable defs
 ****************************************/
class SE_FilesLogger {

public:
    char logpath[192]; // store path here for other methods to use
    char accessLogFile[256]; // store path for access log here

    /* Constructor: Instantiate a logging object bound to the given
       filesystem path prefix. Return pointer to self or NULL
    */
    SE_FilesLogger(char* pathprefix);

    int SE_LogAccess(char* message);
    int SE_LogUserMessage(char* destinationuser, char* sendinguser, char* message);

private: 


}; // end SE_FilesLogger class spec
