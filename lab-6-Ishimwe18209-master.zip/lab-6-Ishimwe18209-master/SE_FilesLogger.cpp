#include "SE_FilesLogger.h"
/*
 * Method definitions for file-based logging class SE_FilesLogger
 */

#include <string>
#include <fstream>

// goes after system includes
#include "SE_FilesLogger.h"

using namespace std;

 /****************************************
  * Class constructor requires path
  ****************************************/
SE_FilesLogger::SE_FilesLogger(char* pathprefix) {

	// Mr. Gold's irritatingly low-level C string manipulation
	// Use C++ string class if you prefer
	strncpy(logpath, pathprefix, sizeof(logpath)); // safely store in member field

	// contatenate prefix and logfile name for later use, store in member field
	sprintf(accessLogFile, "%s%c%s", pathprefix, DIRSEP, "accessLog.txt");

} // end SE_FilesLogger constructor


/****************************************
 * Log given message to file this->pathprefix/accessLog.txt
 ****************************************/
int SE_FilesLogger::SE_LogAccess(char* message) {
  //int main(); // <-- what's this about?
  //{
		ofstream myfile;
		myfile.open(accessLogFile); // <-- open for APPENDING, not overwrite
		myfile << message;
		if (myfile.fail()) {
			return -1;
		}
		myfile.close();
		return 0;
	// };

	return 0;
} // end SE_LogAccess()

int SE_FilesLogger::SE_LogUserMessage(char *destinationuser, char* sendinguser, char* message)
{
	time_t t = time(NULL);
	tm CurrentT = *localtime(&t);
	char buffer[100];
	strftime(buffer, 20, "%m%d%Y_%H%M%S", &CurrentT);
	string strTime(buffer);
	// Issues with trying to combine C char arrays and C++ strings. See suggestions:
	//string lpath = logpath + "messages" + DIRSEP + destinationuser
	//  + DIRSEP + strTime + "_0.txt";
	string mpathprefix(logpath);
	mpathprefix = mpathprefix + "messages" + DIRSEP + destinationuser + DIRSEP + strTime;
  
	struct stat fileTest;
	int T = 1;
	string lpath(mpathprefix+to_string(T)+".txt");
	while (stat(lpath.c_str(), &fileTest) == 0) {
	  //lpath = logpath + "messages " + DIRSEP + destinationuser
	  //	  + DIRSEP + strTime + "_" + to_string(T++) + ".txt";
	  T++;
	  lpath = mpathprefix+to_string(T)+".txt";
	} 

	ofstream myfile(lpath.c_str()); // <-- stray ; removed 

	if (!myfile)
	{
	  printf("Could not open %s's file.\n", destinationuser); // <-- it's already a c string
		return -1;
	}

	myfile << "From: " << sendinguser << ": " << message;
	myfile.close();
	return 0;
}

// Other class methods below here


	// I collaborated with 2/c Tann and 2/c Zachary Barnes helped us with debugging