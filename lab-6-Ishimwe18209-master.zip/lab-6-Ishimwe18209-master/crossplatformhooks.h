/*
  Some preprocessor directives to cover cross-platform builds
  Covers stat functions, directory separator macro, mkdir() macro re-def
  USCGA SE Spring 2021
 */
#ifdef __linux__
#define DIRSEP '/'
#include <dirent.h>
#endif

#ifdef _WIN32
#include <direct.h>
#include "win_dirent.h"
#define DIRSEP '\\'
#define mkdir(A, B) mkdir(A)
#endif

#ifdef __APPLE__
#define DIRSEP '/'
#include <dirent.h>
#endif
