﻿#include "SE-Lab3.h"
#include <iostream>
#include <cmath>

using namespace std;

double getNum() //Function prototype for getNum()
{
	double num = 0.0; //initialize number to 0 value
	cout << "Please input a number: ";
	cin >> num;
		if (cin.fail()) // if there is an invalid response
		{
			cout << "You must enter a number. Please try again: " << endl;
			cin >> num;
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			getNum();
		}
	return num;
}

int getIntNum() //Function prototype for getIntNum()
{
	double num = getNum();
	if (fmod(num, 1 != 0))
	{
		cout << "You must enter an integer. Please try again: " << endl;
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		getIntNum();
	}
	return int(num);
}

int getPosNum() //Function prototype for getPosNum()
{
	double num = getNum();
	if (num < 0)
	{
		cout << "You must enter a positive Number. Please try again: " << endl;
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		getPosNum();
	}
	return num;
}