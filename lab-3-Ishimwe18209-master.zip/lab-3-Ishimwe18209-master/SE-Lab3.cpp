﻿#include "SE-Lab3.h"
#include <iostream>
#include <cmath>

using namespace std;
// function getNum declared

double getNum()
{
	double a = 0.0; // 
	cout << "Enter a double value for a: ";
	cin >> a;

	if (cin.fail())
	{
		cout << "You must enter a number.Please try again: ";
			cin >> a;
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			getNum();
	}
	return a;
}
	// function getIntNum declared
double  getIntNum()
{
	double a = getNum(); // //gets a double and casts it to the int
	if (fmod(a, 1 != 0))
	{
		cout << " You must enter an integer.Please try again." << endl;
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			getIntNum();
	}
	return int(a);
}

//function getPosNum declared

double getPosNum()
{
	double a = getNum(); // //gets a double that is positive and casts it to an int
	if (a < 0)
	{
		cout << "You must enter a positive Number. please try again." << endl;
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		getPosNum();

	}
	return a;
}