﻿// CMakeProject2.h : Include file for standard system include files,
// or project specific include files.

#include <iostream>
// TODO: Reference additional headers your program requires here.

//tfunction getNum
double getNum();
//function getIntNum
double getIntNum();
//function getPosNum
double  getPosNum();