﻿// SE-Lab2.h : Include file for standard system include files,
// or project specific include files.

#pragma once

// TODO: Reference additional header files your program requires here.

// TODO: Function prototype for kineticEnergy()
#include <iostream>
#include <cmath>

using namespace std;

double KineticEnergy(double mass, double velocity);

// TODO: Function prototype for presentValue() {

double presentValue(double FV, double r, double T, double m);
