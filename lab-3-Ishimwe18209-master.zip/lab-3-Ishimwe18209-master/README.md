# Software Engineering Spring 2021 - Lab 3

This lab will focus on the following areas of software development:
* Input validation
* Building libraries
* Adding code files from an existing project
* Working with a version control system (Github)
* Boolean values
* Casting

## Input Validation
Software design and implementation must be resillient. In other words, a program should not crash or exhibit unintended behaviour because inputs are not handled correctly. In order to ensure this takes place developers must examine software requirements and ensure that their code accepts the required input formats and gracefully handles outlier inputs. Low level languages such as C and C++ facilitate receiving input and output, but not functionality to handle all possible inputs. In Lab 1 you reviewed the cplusplus.com "Basic Input/Output" tutorial, which you can serve as your starting point for this lab. This section focuses on the use of the C++ standard input/output streams and the stream extraction/insertion operators. Input validation is not a one-time operation. You should expect the input to be invalid until it's *not*.

#### 1. Clone this repository using Visual Studio.

#### 2. Using the provided source and header file (.cpp and .h) in the repo folder tree:

**Graded Items:** 
* Create a function called getNum(): This function should return a double value. If the input results in an error condition, the program must output, "You must enter a number. Please try again:", and (as stated in the output message) get user input again. **[1 Point]**
* Create a function called getIntNum(): This function should return an integer value, and leverage getNum() to get a double. Use casting to evaluate the input as an integer. If the cast fails, the program must output, "You must enter an integer. Please try again:", and (as stated in the output message) get user input again. **[1 Point]**
* Create a function called getPosNum(): This function should return an integer value, and leverage getNum() to get a double. Evaluate whether the number is positive or not. If the number isn't positive, the program must output, "You must enter a positive Number. Please try again:" **[1 Point]**

## Using existing code (code re-use)
Once code is written, the same logic can be reused across projects. In this section, you will copy your code from Lab 2 into this lab with the goal being to combine the code from both labs to provide sanitized inputs to **kineticEnergy()** and **presentValue()**. 

**Graded Items:** 
* Copy your function files from Lab 2 into the repo folder tree, include them into your existing Lab 3 code, and give CMake visibility for build purposes. **[1 Point]**


## Building Libraries:
In Lab 2 we focused on creating functions that allow programmers to easily re-use logic. In Lab 3 we are taking the concept one step further by combining functions into a library that further facilitates re-use of code with programs. Libraries represent a pre-compiled version of function objects (and/or classes) that developers can included in code. For the purposes of this lab, there are two library types: 
* Static libraries: [Windows](https://www.learncpp.com/cpp-tutorial/a1-static-and-dynamic-libraries/)(.lib) and [Linux](https://tldp.org/HOWTO/Program-Library-HOWTO/static-libraries.html)(.a) 
* Dynamic libraries: [Dynamic Link Libraries](https://docs.microsoft.com/en-us/windows/win32/dlls/dynamic-link-libraries) on Microsoft Windows (.dll); [Shared libraries](https://www.tecmint.com/understanding-shared-libraries-in-linux/) on Linux (.so) 


**Graded Items:**
* Using the links in the paragraph above, provide a short description of the difference between static libraries and dynamic libraries. **[1 Point]**
* Build your Lab 2 and Lab 3 source code as a library instead of an executable. The CMake tutorial [has a section](https://cmake.org/cmake/help/latest/guide/tutorial/index.html#adding-a-library-step-2) that will help guide you. **[2.5 Points]**
* Create or re-use your main.cpp from Lab 2 to build an executable that includes your library code from the previous step. **[2.5 Points]**

** difference between static library and dynamic library
//A dynamic library consists of routines that are loaded into your application at run time.When you compile a program that uses a dynamic library, the library does not become part of your executable whereas A static library consists of routines that are compiled and linked directly into your program. When you compile a program that uses a static library, all the functionality of the static library that your program uses becomes part of your executable.