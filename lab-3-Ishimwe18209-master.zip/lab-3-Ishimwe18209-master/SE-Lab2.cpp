﻿// SE-Lab2.cpp : Defines two functions 
//

#include "SE-Lab2.h"
using namespace std;

// TODO: Function implemenation for kineticEnergy()

double KineticEnergy(double mass, double velocity)
{
	double k;
	k = ((1 / 2) * mass) * (pow(velocity, 2));
	return k;
	
}
// TODO: Function implemenation for presentValue()

double presentValue(double FV, double r, double T, double m)
{
	// FV = future value of money
	   // r= annual interest rate %
	  // T = number of years
	//m = number of periods basedon compound frequencing
	double PV;
	PV = (FV) / pow(1.0 + (r / m), m * T);
	return PV;
}
