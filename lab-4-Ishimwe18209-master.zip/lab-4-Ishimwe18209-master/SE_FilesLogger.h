//#pragma once
//#include <filesystem.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#ifdef __linux__
#include <linux/stat.h>
#define DIRSEP '/'
#endif

#ifdef _WIN32
#include <direct.h>
#define DIRSEP '\\'
#endif

#ifdef __APPLE__
#include <sys/stat.h>
#define DIRSEP '/'
#endif


/****************************************
 * Class specification, includes method prototypes
 * and public/private member variable defs
 ****************************************/
class SE_FilesLogger
{

public:
    char logpath[192]; // store path here for other methods to use
    char accessLogFile[256]; // store path for access log here

    /* Constructor: Instantiate a logging object bound to the given
       filesystem path prefix. Return pointer to self or NULL
    */
    SE_FilesLogger(char* pathprefix);

    int SE_LogAccess(char* message);

    int SE_logUserMessage(char* destinationuser, char* sendinguser, char* message);

private:


}; // end SE_FilesLogger class spec
