/* Test wrapper w/ main for logging files in Lab4 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string>
#include <iostream>

#ifdef __linux__
#include <linux/stat.h>
#endif

#ifdef _WIN32
#include <direct.h>
#endif

#ifdef __OSX__
#include <direct.h>
#endif


#include "SE_FilesLogger.h"


#define SUCCESS  0
#define NOARGS  -1
#define BADSTAT -2

using namespace std;

int main(int argc, char** argv) {

    char* prefixdir = NULL;
    struct stat dirstats;
    int staterr = 0;


    /* Data directory from very simplistic commandline argument, if given */
    if (argc > 1) {

        prefixdir = argv[1];
        staterr = stat(prefixdir, &dirstats); // If we can stat it, it exists

        if (staterr)
        { // stat returns 0 on success, a variety of ints on failure
            printf("stat() of directory %s failed with exit code: %d\n",
                prefixdir, staterr);
            return(BADSTAT);
        }

    }
    else 
    { // no commandline args given
        printf("A data directory path argument is required.\n");
        return(NOARGS);
    } // end directory arg validation

    SE_FilesLogger mylogger(prefixdir); // create a new logging object

    // Check Constructor results:
    printf("logging instance has path prefix: %s\n", mylogger.logpath); // constrains working properly for logpath 
    printf("AccessLog has path prefix: %s\n", mylogger.accessLogFile); // constrains working properly for accessloglife



    // Test other logging class methods:

    printf("Test logAccess: %d\n", mylogger.SE_LogAccess("Ishimwe's Message\n"));
    printf("Test logUserMessage: %d\n", mylogger.SE_logUserMessage("Ishimwe", "vivine", "message 2 is here\n"));
    printf("Test logUserMessage: %d\n", mylogger.SE_logUserMessage("Ishimwe", "vivine", "message 2 is here\n"));


    //Test a  broken instance:
    SE_FilesLogger brokenLogger("C:/Window/System32/");
    printf("logging instance path prefix: %s\n", brokenLogger.logpath);
    printf("AccessLog path prefix: %s\n", brokenLogger.accessLogFile);

    //Test another logging class method:
    printf("Test logAccess: %d\n", brokenLogger.SE_LogAccess("Ishimwe's Message\n"));
    printf("Test logUserMessage: %d\n", brokenLogger.SE_logUserMessage("Ishimwe","Vivine", "message 1 is here\n"));
    printf("Test logUserMessage: %d\n", brokenLogger.SE_logUserMessage("Ishimwe", "vivine","message 2 is here\n"));

    return SUCCESS;
}
