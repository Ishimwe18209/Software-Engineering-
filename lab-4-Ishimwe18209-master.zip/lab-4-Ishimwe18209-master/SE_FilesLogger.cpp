
/*
 * Method definitions for file-based logging class SE_FilesLogger
 */

#include <fstream>
#include <string>
#include "SE_FilesLogger.h"

using namespace std;


 /****************************************
  * Class constructor requires path
  ****************************************/
SE_FilesLogger::SE_FilesLogger(char* pathprefix) 
{

	strncpy(logpath, pathprefix, sizeof(logpath)); // safely store in member field

	// contatenate prefix and logfile name for later use, store in member field
	sprintf(accessLogFile, "%s%c%s", pathprefix, DIRSEP, "accessLog.txt");

} // end SE_FilesLogger constructor

/****************************************
 * Log given message to file this->pathprefix/accessLog.txt
 ****************************************/
int SE_FilesLogger::SE_LogAccess(char* message)
{
	ofstream myfile;
	myfile.open("accessLogFile");
	if (myfile)
		myfile << message << '\n';
	myfile.close();

	string line;
	string messageText;
	ifstream testfile;
	if (testfile.is_open())
	{
		while (getline(testfile, line))
		{
			messageText = messageText + line;
		}
		myfile.close();
	}
	else
	{
		return -1; // opening file failed
	}
	if (messageText.compare(string(message)) != 0)
	{
		return -1; // message in the file doesn't equal inputted fil
	}
	else
	{
	return 0; // this works, yeah yeah
 }
	
} // end SE_LogAccess()

int SE_FilesLogger::SE_logUserMessage(char* destinationuser, char* sendinguser, char* message)

 {
	time_t t = time(NULL); // time will be present in my folder
	tm CurrentT = *localtime(&t);
	char buffer[20]; // <-- will need to be bigger than 10: imagine 02252021_144527
	strftime(buffer, 50, "%m%d%Y_%H%M%S", &CurrentT);
	string strTime(buffer);
	//string lpath = logpath + "messages/" + destinationuser + "/" + strTime + "_0.txt"; // send time to the folder
	
	// create a new C++ string from this one C characer array. Note the consistent
	// use of basic C types, then converting to a C++ class. It's hard to mix them
	// together in a single statement:
	char tmppath[256];
	sprintf(tmppath,"%s%c%s%c%s%c%s", logpath, DIRSEP, "messages", DIRSEP,
		destinationuser, DIRSEP, buffer); // send time to the folder
	string lpath(tmppath); // <-- now create the C++ string w/o the integer suffix

	struct stat fileTest;
	int T = 10;

	// Note strategy of using the long prefix up to the counter, then adding
	// the long prefix plus the counter plus the suffix to get each successive
	// filename to test:
	string suffix(".txt");
	string lpathcount(lpath + to_string(T) + suffix);
	while (stat(lpath.c_str(), &fileTest) == 0) {
	  lpathcount = lpath + to_string(T) + suffix;
	}

	ofstream file(lpath.c_str());

	if (!file)
	{
		printf("doesn't open at all %s's file.\n", destinationuser); // display this if file failed to open
		return -1;
	}

	file << "From: " << sendinguser << ": " << message;
	file.close();
	return 0;
}


