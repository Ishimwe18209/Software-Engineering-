# Software Engineering Spring 2021 - Lab 4
This lab kicks off a multi-week assignment to build a self contained command line messaging program. Each week's lab will build a portion of the project. Please see the "SE Lab 4+ OVERVIEW" in the D2L week 4 documents for further information. This week will focus on the following areas of software development:
* Classes
* Constructors
* File I/O
* Wrapper Programs
* Time

## Classes
The objective of this lab is to write a messaging class in C++ that supports logging information to flat text files in the filesystem. You have been provided with the class files ```SE_FilesLogger.cpp``` and ```SE_FilesLogger.h``` as your starting point. This lab builds on the concepts from Lab 3 where the code you create isn't responsible for running itself, but rather is part of a greater suite of code that is run from main() elsewhere. *Your class files should not include main()*.

**Graded Items**
1. Create a constructor that takes a *Character string* that represents a file path prefix and returns a reference to itself If instantiated correctly, else NULL **[1 point]**
2. Create a method logAccess() that returns an integer and takes a single Character string argument named "message". The method should write the contents of message to a log file ``` filepathprefix/accessLog.txt```, account for situations if the file cannot be written to the file system, and returns 0 on success, -1 on failure. **[2 points]**
3. Create a method logUserMessage() that returns an integer and takes the Character string arguments "destinationuser", "sendinguser", and "message" that:
* Writes the string ```"from (sendingUser): (message)"``` to a file at: ```pathprefix/messages/destinationuser/YYYYMMDD_HHMMSS_X.txt ```where \'*YYYYMMDD_HHMMSS\'* is year,month,day_hour,minutes,seconds such as 20210125_132758 and \'X\' is an integer from 0. **[1 point]**
* If the file already exists, increment the value of X until a message can be written. This will reduce collisions on a per-second basis. The file doesn't exist, the file is created and information written to the file. **[1 point]** 
* Accounts for situations if the file cannot be written to the file system and returns 0 on success, -1 on failure. **[1 point]**
    
## Wrapper Programs
The word "wrapper" is a widely used term in software engineering. For instance, you will often see mentions of wrapper functions and wrapper classes. [According to the creator of C++](https://www.stroustrup.com/wrapper.pdf), this takes the form of ```begin-transaction do-something end-transaction```. For this lab you have also been provided with ```SE-Lab4-tests.cpp``` that is used as a wrapper program for your ```SE_FileLogger``` class. This is accomplished through the use of main() in the file to instantiate the class and test functionality by calling its methods. 

**Graded Items**

4. Edit ```CMakeLists.txt``` such that your class code and the test wrapper build into an executable file. **[1 point]**

5. Call logAccess() and test both success and failure conditions. **[1 point]**

6. Call logUserMessage() and test both success and failure conditions **[1 point]**


**References**

-   http://cplusplus.com

-   https://www.cplusplus.com/reference/array/array/

- https://www.cplusplus.com/reference/ctime/
