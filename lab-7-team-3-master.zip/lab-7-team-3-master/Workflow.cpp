#include "Workflow.h"

int main(int argc, char* argv[]) {

	char* prefixdir = NULL;
	struct stat dirstats;
	int staterr = 0;
	
	if (argc > 1) {

		prefixdir = argv[1];
		staterr = stat(prefixdir, &dirstats); // If we can stat it, it exists

		if (staterr) { // stat returns 0 on success, a variety of ints on failure
			printf("stat() of directory %s failed with exit code: %d\n",
				prefixdir, staterr);
			return(BADSTAT);
		}

	}
	else { // no commandline args given
		printf("A data directory path argument is required.\n");
		return(NOARGS);
	} // end directory arg validation
	char loginString[256];
	char greeting[20];
	time_t tim;
	struct tm* det1;
	char time_buff[100];
	time(&tim);
	det1 = localtime(&tim);
	strftime(time_buff, sizeof(time_buff), "%H", det1);
	if ((time_buff[0] == '1') && (time_buff[1] < 50)) {
		strcpy(greeting, "\nGood morning! ");
	}
	else if ((time_buff[0] == '1') && (time_buff[1] < 56)) {
		strcpy(greeting, "\nGood afternoon! ");
	}
	else if ((time_buff[0] == '1')) {
		strcpy(greeting, "\nGood evening! ");
	}
	else if ((time_buff[0] == '2')) {
		strcpy(greeting, "\nGood evening! ");
	}
	else if ((time_buff[0] == '0')) {
		strcpy(greeting, "\nGood morning! ");
	}
	else
		strcpy(greeting, "\nHello! ");
	

	SE_FilesLogger logObject(prefixdir);

bool goback;

LOOP:do {
	goback = 0;
	cout << greeting << "Welcome to Team Dan Message Retrival System. \nEnter one of the following characters: \n\n";
	cout << "l (Login to User) \nr (Register User) \nq (quit)\n ";

	char menuselect;
	cin >> menuselect;
	switch (menuselect) {
	case 'l': //log in case
	{
		char messageDirectory[256];
		sprintf(messageDirectory, "%s%c%s", prefixdir, DIRSEP, "Messages");
		bool isempty;
		struct dirent* name;
		DIR* dir;
		dir = opendir(messageDirectory); //Change users/messages
		int count = 0;
		while ((name = readdir(dir)) != NULL) {
			count++;
		}
		if (count > 2) {
			isempty = false;
			//log that folder was not empty
			//Then the directory is not empty
		}
		else
			isempty = true;//log that folder was empty

		// Workflow 1
		if (isempty) {
			cout << "No users have been created. Please enter a username.\n (Cannot include characters: , . / ; : ' | ] } [ { + = )(*&^%$#@!~`?<>\\) \n";
			cout << "**(Enter in '$' to exit back to menu)\n";
			char newuser[256];
			cin >> newuser;
			goback = backToMenu(newuser);
			if (goback)
				goto LOOP;

			int check = goodString(newuser);

			while (!check) {
				cout << "Bad Input! \n (Cannot include characters: , . / ; : ' | ] } [ { + = )(*&^%$#@!~`?<>\\) \n";
				cout << "Enter a valid username: \n";
				cout << "**(Enter in '$' to exit back to menu)\n";
				cin >> newuser;
				bool goback = backToMenu(newuser);				
				if (goback)
					goto LOOP;
				check = goodString(newuser);

			}

			cout << "Set a new password:\n";
			cout << "**(Enter in '$' to exit back to menu)\n";
			char newpw[64];
			cin >> newpw;
			goback = backToMenu(newpw);
			if (goback)
				goto LOOP;

			//create user class and make the user
			SE_User newuserobj(prefixdir, newuser);
			sprintf(loginString, "User created - %s", newuser);
			logObject.SE_Log(loginString, 1);
			int createError = newuserobj.createUser();
			if (createError<0) {
				logObject.SE_Log("Username not usable - createUser",0);
			}
			int setPError = newuserobj.setPassword(newpw);
			if (setPError < 0) {
				logObject.SE_Log("Password is already set - setPassword", 0);
			}
			int saveUserError = newuserobj.saveUser();
			if (saveUserError < 0) {
				switch (saveUserError) {
				case -1:
					logObject.SE_Log("Unable to write to file - saveUser", 0);
					break;
				case -2:
					logObject.SE_Log("Unable to open file - saveUser", 0);
					break;
				case -3:
					logObject.SE_Log("Unable to build user directory - saveUser", 0);
					break;
				case -4:
					logObject.SE_Log("Unable to build message directory - saveUser", 0);
					break;
				default:
					logObject.SE_Log("Unknown - saveUser", 0);
					break;
				}
			}
			// make and set password in user clas
			isempty = 0;
		}
		
		// Workflow 2
		else if (!isempty) {

			char username[256];
			char path[256];
			cout << "Enter your Username:" << endl;
			cout << "**(Enter in '$' to exit back to menu)\n";
			cin >> username;
			goback = backToMenu(username);
			if (goback)
				goto LOOP;

			sprintf(path, "%s%c%s%c", prefixdir, DIRSEP, "Messages", DIRSEP);
			strcat(path, username);

			struct stat dirstats;
			int staterr = 0;
			staterr = stat(path, &dirstats);
			if (staterr == 0) {
				cout << "Username Found!" << endl;

			}
			else {
				cout << "User does not exist. Enter a valid username. (Case Matters)" << endl;
				while (1) {
					cout << "Enter your Username:" << endl;
					cout << "**(Enter in '$' to exit back to menu)\n";
					cin >> username;
					goback = backToMenu(username);
					if (goback)
						goto LOOP;

					sprintf(path, "%s%c%s%c", prefixdir, DIRSEP, "Messages", DIRSEP);
					strcat(path, username);

					struct stat dirstats;
					int staterr = 0;
					staterr = stat(path, &dirstats);
					if (staterr == 0) {
						cout << "Username Found!" << endl;

						break;
					}
					else {
						cout << "User does not exist. Enter a valid username." << endl;
					}
				}

			}
			SE_User currentuser(prefixdir, username);
			int loadError = currentuser.loadUser();
			if (loadError < 0) {
				switch (loadError) {
				case -1:
					logObject.SE_Log("Username not set - loadUser", 0);
					break;
				case -2:
					logObject.SE_Log("userFile.txt does not exist - loadUser", 0);
					break;
				case -3:
					logObject.SE_Log("Unable to open userFile.txt - loadUser", 0);
					break;
				default:
					logObject.SE_Log("Unknown - loadUser", 0);
					break;
				}
			}

			cout << "Enter your password: \n";
			cout << "**(Enter in '$' to exit back to menu)\n";
			char pwUserEntry[64];
			cin >> pwUserEntry;
			goback = backToMenu(pwUserEntry);
			if (goback)
				goto LOOP;

			int verify = currentuser.authenticate(pwUserEntry);
			while (verify == 1) {
				cout << "Incorrect password!\n";
				cout << "\nEnter your password: \n";
				cout << "**(Enter in '$' to exit back to menu)\n";
				cin >> pwUserEntry;
				goback = backToMenu(pwUserEntry);
				if (goback)
					goto LOOP;

				int verify = currentuser.authenticate(pwUserEntry);
				if (verify == 0)
					break;
			}
			sprintf(loginString, "Log in successful - %s", username);
			logObject.SE_Log(loginString, 1);
			// User data is loaded and pw has been authenticated. List messages and allow them to read/write. (use seperate class??)
			// List messages: Use same code from list usernames.
			char yn;
			cout << "Read messages? (y/n) \n";
			cin >> yn;
			if (yn == 'y') {
				char userMsgs[100];
				char pathdest[256];				
			LOOPmsg: do { 	// Read messages: Take input from user and then print out contents to console
					int checkListMsg = currentuser.listMessages();
					if (checkListMsg < 0) {
						switch (checkListMsg) {
						case -1:
							logObject.SE_Log("Unable to open a directory - listMessages", 0);
							break;
						case -2:
							logObject.SE_Log("Unable to open userFile.txt - listMessages", 0);
							break;
						default:
							logObject.SE_Log("Unknown - listMessages", 0);
							break;
						}
					}
					cout << "Select a user to read from.";
					cout << "**(Enter in '$' to exit back to menu)\n";
					cin >> userMsgs;
					goback = backToMenu(userMsgs);
					if (goback)
						goto LOOP;
					break;
				} while (1);
				sprintf(pathdest, "%s%c%s%c%s", prefixdir, DIRSEP, "Messages", DIRSEP, userMsgs);
				struct stat dirstats;
				int staterr = 0;
				staterr = stat(pathdest, &dirstats);
				if (staterr == 0) {
					int checkReadMsg = currentuser.readMessage(userMsgs);
					if (checkReadMsg < 0) {
						switch (checkReadMsg) {
						case -1:
							logObject.SE_Log("Unable to open a directory - readMessage", 0);
							break;
						case -2:
							logObject.SE_Log("Unable to open userFile.txt - readMessage", 0);
							break;
						default:
							logObject.SE_Log("Unknown - readMessage", 0);
							break;
						}
					}
					cout << "Going back to menu. \n";
					goto LOOP;
				}
				else {
					cout << "User does not exist. \n";
					goto LOOPmsg;
				}
			}
			else if (yn == 'n') {
				cout << "Send a message?. (y/n) \n";
				char yn1;
				cin >> yn1;

				LOOPs: do{  // Write message: list the users that message can be sent to. then take user input for a user
				if (yn1 == 'y') { //	      check if that user exists. then use loggger to write the message and send to
					char destuser[64];//	  that user
					char pathdest[256];
					cout << "Available Users: \n";
					int errorList = currentuser.listUserNames();
					if (errorList < 0) {
						logObject.SE_Log("Unable to open a directory - listUserNames", 0);
					}
					cout << "Please select a user: \n";
					cout << "**(Enter in '$' to exit back to menu)\n";
					cin >> destuser;
					
					goback = backToMenu(destuser);
					if (goback)
						goto LOOP;
					sprintf(pathdest, "%s%c%s%c%s", prefixdir, DIRSEP, "Messages", DIRSEP, destuser);
					struct stat dirstats;
					int staterr = 0;
					staterr = stat(pathdest, &dirstats);
					if (staterr == 0) {
						char message[256];
						cout << "Type your message: \n";
						//cin >> message;
						cin.ignore();
						cin.getline(message,256);
						
						int logError = logObject.SE_LogUserMessage(destuser, currentuser.username, message);
						if (logError < 0) {
							switch (logError) {
							case -1:
								logObject.SE_Log("Unable to open file - logUserMessage", 0);
								break;
							case -2:
								logObject.SE_Log("Unable to write message to file - logUserMessage", 0);
								break;
							default:
								logObject.SE_Log("Unknown - logUserMessage", 0);
								break;
							}
						}
						cout << "Message Sent. \n";
						cout << "Send a another message?. (y/n) \n";
						cin >> yn1;
						if (yn1 == 'y')
							goto LOOPs;
						else if (yn1 == 'n') {
							cout << "Going back to menu. \n";
							goto LOOP;
						}
					}
				}
				else if (yn1 == 'n') {
					cout << "Going back to menu. \n";
					goto LOOP;
				}
				} while (1);
				
			}			
		}
	}
	break;

	case 'r': //register user case
	{
		cout << "Please enter a username.\n(Cannot include characters : , . / ; : ' | ] } [ { + = )(*&^%$#@!~`?<>\\) \n";
		cout << "**(Enter in '$' to exit back to menu)\n";
		char newuser[64];
		cin >> newuser;
		goback = backToMenu(newuser);
		if (goback)
			goto LOOP;
		int check = goodString(newuser);

		while (!check) {
			cout << "Bad Input! \n (Cannot include characters: , . / ; : ' | ] } [ { + = )(*&^%$#@!~`?<>\\) \n";
			cout << "Enter a valid username: \n";
			cout << "**(Enter in '$' to exit back to menu)\n";
			cin >> newuser;
			goback = backToMenu(newuser);
			if (goback)
				goto LOOP;
			check = goodString(newuser);
		}
		char path[256];
		sprintf(path, "%s", prefixdir);
		SE_User createNewUser(path,newuser);

		int exists = 0;
		exists = createNewUser.createUser();
		if (exists) {
			LOOPr: while (exists) {
				cout << "Username taken.\n\n";
				cout << "Please enter a username.\n(Cannot include characters : , . / ; : ' | ] } [ { + = )(*&^%$#@!~`?<>\\) \n";
				cout << "**(Enter in '$' to exit back to menu)\n";
				cin >> newuser;
				goback = backToMenu(newuser);
				if (goback)
					goto LOOP;
				int check = goodString(newuser);

				while (!check) {
					cout << "Bad Input! \n (Cannot include characters: , . / ; : ' | ] } [ { + = )(*&^%$#@!~`?<>\\) \n";
					cout << "Enter a valid username: \n";
					cout << "**(Enter in '$' to exit back to menu)\n";
					cin >> newuser;
					goback = backToMenu(newuser);
					if (goback)
						goto LOOP;
					check = goodString(newuser);
				}
				SE_User createNewUser(path, newuser);
				exists = createNewUser.createUser();
				if (exists)
					goto LOOPr;
				cout << "Set a new password:\n";
				cout << "**(Enter in '$' to exit back to menu)\n";
				char newpw[64];
				cin >> newpw;
				goback = backToMenu(newpw);
				if (goback)
					goto LOOP;
				createNewUser.setPassword(newpw);
				int saveUserError = createNewUser.saveUser();
				sprintf(loginString, "User created - %s", newuser);
				logObject.SE_Log(loginString, 1);
				if (saveUserError < 0) {
					switch (saveUserError) {
					case -1:
						logObject.SE_Log("Unable to write to file - saveUser", 0);
						break;
					case -2:
						logObject.SE_Log("Unable to open file - saveUser", 0);
						break;
					case -3:
						logObject.SE_Log("Unable to build user directory - saveUser", 0);
						break;
					case -4:
						logObject.SE_Log("Unable to build message directory - saveUser", 0);
						break;
					default:
						logObject.SE_Log("Unknown - saveUser", 0);
						break;
					}
				}
				cout << "User created!\n";
				goto LOOP;
			}
		}
		else {
			cout << "Set a new password:\n";
			cout << "**(Enter in '$' to exit back to menu)\n";
			char newpw[64];
			cin >> newpw;
			goback = backToMenu(newpw);
			if (goback)
				goto LOOP;
			createNewUser.setPassword(newpw);
			int saveUserError = createNewUser.saveUser();
			sprintf(loginString, "User created - %s", newuser);
			logObject.SE_Log(loginString, 1);
			if (saveUserError < 0) {
				switch (saveUserError) {
				case -1:
					logObject.SE_Log("Unable to write to file - saveUser", 0);
					break;
				case -2:
					logObject.SE_Log("Unable to open file - saveUser", 0);
					break;
				case -3:
					logObject.SE_Log("Unable to build user directory - saveUser", 0);
					break;
				case -4:
					logObject.SE_Log("Unable to build message directory - saveUser", 0);
					break;
				default:
					logObject.SE_Log("Unknown - saveUser", 0);
					break;
				}
			}
			goto LOOP;
		}


	}
	break;

	case 'q': //quit case
		cout << "Goodbye! \n";
		return 0;
		break;

	default:
		cout << "Invalid Menu Input" << endl;
		goto LOOP;
	}

}
while (goback);

}

