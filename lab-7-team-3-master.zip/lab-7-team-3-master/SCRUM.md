# Software Engineering Spring 2021 - Lab 6



## Workload Allocation

1. Workflow - Jaden
2. User class - Liz
3. Logger class - Vivine
4. Validation - Tann & Dan
5. Test main - Mac

## History

 1. Updated Logger to have both error and message logging

## Workflow Pseudo
 �Good � *Time of day* Would you like to log in, register, Quit? 
	Receive input (l, r, q)
	If log in but no users exist in folder: error -> main menu
	If log in with users, list users and prompt for username
		If username isn�t valid, error -> main menu
		If username is valid, ask for password
			If password is incorrect: Error
				On three failures log log-in failure and return to main menu
			If password is correct: Good to go, log in
	If quit, terminate program
	If register, show register prompt
		Ask for a valid username
			If invalid username, list parameters
			If taken username, list usernames
			If its good to go, create the user and log in

	Logged in
		List options (change password, message user, list(show) messages, read messages, list users) (p,m,s,r,l)

## Pseudo Development
 switch(charVariable){ //Main menu switch
	case 'l': 
		//log in 
		break;
	case 'r': 
		//register 
		break;
	case 'q': 
		//quit
		break;
	default:
		//nonvalid case received
		break;
 }
 switch(charVariable){ //logged in menu switch
	case 'p': 
		//change password 
		break;
	case 'm': 
		//message user
		break;
	case 's': 
		//list (show) messages
		break;
	case 'r': 
		//read message
		break;
	case 'l': 
		//list users
		break;
	default:
		//nonvalid case received
		break;
 }


## To Do

 Replace all of the logError calls and instead have the return value be caught by the logger class
 
 Actually use the SCRUM document



## Conversion issues

 1.	Example problem  (RESOLVED)

 2. Having to fix the CMakefile to work with all of the files

 3. User class ?

