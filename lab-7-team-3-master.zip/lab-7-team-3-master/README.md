# Software Engineering Spring 2021 - Lab 7
This lab will focus on the following areas of software development:

* User Workflow
* Integration

This is the final technical lab in the 1st half of the semester's lab
series. Over the next week, you will combine your developed components
into a final working program by implementing the actual user
workflows. You will test your program in as many scenarios as you can
imagine, including both proper and improper use. You will write a
reflection document on this integration process. You will almost surely discover that refactoring or re-architecting code is
necessary. You are empowered to make such decisions as necessary to
complete the project while maintaining the fundamental structure and
intent of the lab series and overall use case outlined in the OVERVIEW doc.

## Requirements

#### 1. Organize into your lab/project teams:
These will be the teams that you maintain for the second half of the
course's project-based work. Choose wisely. Teams must be four or five
individuals. Six is right out. You will work in a shared github
repository. You must all be able to check out the repo to your local
machine, and check in to the shared repo for your group. You will submit one repo per group.

#### 2. Select a component, class, module, or test suite from DIFFERENT members' projects:
Team members are expected to contribute portions of their code from previous labs to contribute to the overall integration effort. No two components should come from a single team members project. The lone exception is that teams may combine their test suites from previous work. 

#### 3. Implement the main() program that will interact with the user to send and receive messages:
You may choose two or more primary developers. One is too few; Five is too many.
Assign one or two members to code test cases in a separate test file with its own main().
Assign one or two members to write user test scenarios (good and bad inputs to validate functionality).

------------

**Graded Items**

 * A combined repository with components from different projects. Must compile. **[1 point]**

 * Workflow 1: If NO users exist, prompt the user to create the first user and then exit. **[1 point]**
 
 * Workflow 2: If any users exist, prompt the user to authenticate
   themselves (username and password) and then display a menu of
   options (any order). You will need to track which user is logged
   in, and that they are authenticated. Recommendation: write the
   interactive menu *without* calling the backend processes yet. Then
   plumb in the calls to the other object methods. Remember to LOG
   USAGE AND ERRORS using your logging object/class. Include timestamps
   at the beginning of each log message.

 
     1. Change Password **[1 point]**
		- User may only change their own password
	 2. Send Message **[1 point]**
	    - May only send to existing users
	 3. List Messages **[2 points]**
	    - May only list own messages
	 4. Read Message **[2 points]**
	    - May only read own messages
	 5. Create New User **[2 points]**
	    - Prompt for new username and password. May only create users
          that do not exist (else password would be overwritten, which
          would be bad.)

#### Coming in Lab 8: Write a ~2 page reflection paper on your experience of integrating components
This will require you to bring together the lecture/theory portion of
the class and your lab/technical experience. Describe what went well
and what didn't. Speculate on how you can use what you've observed in
this experience to improve chances of success with a larger group
project. Document who's components were used and what roles you have
each played in the final integration effort. The more challenging your
integration effort, the more we will expect to see in your
reflection. Store the paper in the repository. It may be in Word, PDF,
or Markdown formats.  Assign at least one member to lead the
reflection paper. Begin making notes during this lab's sprint.
