#include <filesystem>
#include <fstream>
#include <string>
#include <iostream>
#include "crossplatformhooks.h"
#include "SE_User.h"
#include "SE_FilesLogger.h"
#include "validation.h"

#define SUCCESS  0
#define NOARGS  -1
#define BADSTAT -2

using namespace std;

int main(int argc, char* argv[]) {
    char* prefixdir = NULL;
    struct stat dirstats;
    int staterr = 0;


    /* Data directory from very simplistic commandline argument, if given */
    if (argc > 1) {

        prefixdir = argv[1];
        staterr = stat(prefixdir, &dirstats); // If we can stat it, it exists

        if (staterr) { // stat returns 0 on success, a variety of ints on failure
            printf("stat() of directory %s failed with exit code: %d\n",
                prefixdir, staterr);
            return(BADSTAT);
        }

    }
    else { // no commandline args given
        printf("A data directory path argument is required.\n");
        return(NOARGS);
    } // end directory arg validation


    //- create logging object
    SE_FilesLogger mylogger(prefixdir);
    //- log an error
    mylogger.SE_Log("Boom.", 0);
    //- log an access
    mylogger.SE_Log("Hacked the mainframe!", 1);

	//- create user1
    SE_User user1(prefixdir, "User1");
	//- create user2
    SE_User user2(prefixdir, "User2");

    //- setpassword of user1
    user1.setPassword("Password");
    printf("User 1 pw: %s\n", user1.currentpw);
    //- setpassword of user2
    user2.setPassword("default");
    printf("User 2 pw: %s\n", user2.currentpw);
    //- changepassword of user1
    user1.changePassword("Password", "P4ssw0rd");
    printf("User 2 pw: %s\n", user2.currentpw);

	//- save user1
    user1.saveUser();
	//- list users
    user1.listUserNames();
    //- save user2
    user2.saveUser();
	
    printf("\n Messages \n");
    user1.listMessages();

    printf("\n Reading! \n\n");
    user1.readMessage("User2"); 

    //- send message from user1 to user2
    mylogger.SE_LogUserMessage("User1", "User2", "New Message!");
    mylogger.SE_LogUserMessage("User1", "Ghost", "Boo Hoo");








//# sending message to the users
//- sending a blank message
//- sending a valid number and a clear text
//- sending message to yourself
//-sending message to an invalid user
//# creating the user
//- creating the username
//- creating password
//- password should include letters, numbers, and symbols
//# changing the password
//- Require the old password
//- input a new password
//- confirm a new password
//# Reading Messages
//- read by character or line by line
//- able to reply		-- add this functionality?
//- show the message was seen		--maybe
//# Listing Messages
//- show the sender
//- show the timestamp( day and time)
//- New messages at the top
//- separating the different messages so that they all don't come at the same time.( separation)
//- Messages expires after three months

}
