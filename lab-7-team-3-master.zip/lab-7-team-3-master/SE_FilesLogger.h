#pragma once
//#include <filesystem.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>


#ifdef __linux__
#define DIRSEP '/'
#include <dirent.h>
#endif

#ifdef _WIN32
#include <direct.h>
#include "win_dirent.h"
#define DIRSEP '\\'
#define mkdir(A, B) mkdir(A)
#endif

#ifdef __APPLE__
#define DIRSEP '/'
#include <dirent.h>
#endif


/****************************************
 * Class specification, includes method prototypes
 * and public/private member variable defs
 ****************************************/
class SE_FilesLogger {

public:
    char logpath[192]; // store path here for other methods to use
    char accessLogFile[256]; // store path for access log here
    char errorLogFile[256]; // store path for error log here

    /* Constructor: Instantiate a logging object bound to the given
       filesystem path prefix. Return pointer to self or NULL
    */
    SE_FilesLogger(char* pathprefix);

    int SE_Log(char* message, int accessTrue);
    int SE_LogUserMessage(char* destinationuser, char* sendinguser, char* message);

private: 


}; // end SE_FilesLogger class spec
