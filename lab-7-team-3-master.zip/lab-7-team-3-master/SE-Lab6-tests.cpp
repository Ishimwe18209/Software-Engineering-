/* Test wrapper w/ main for logging files in Lab4 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>

#ifdef __linux__
#include <linux/stat.h>
#endif

#ifdef _WIN32
#include <direct.h>
#endif

#ifdef __OSX__
#include <direct.h>
#endif


#include "SE_FilesLogger.h"
#include "SE_User.h"
#include "validation.h"



#define SUCCESS  0
#define NOARGS  -1
#define BADSTAT -2


int main(int argc, char** argv) {

    char* prefixdir = NULL;
    struct stat dirstats;
    int staterr = 0;


    /* Data directory from very simplistic commandline argument, if given */
    if (argc > 1) {

        prefixdir = argv[1];
        staterr = stat(prefixdir, &dirstats); // If we can stat it, it exists

        if (staterr) { // stat returns 0 on success, a variety of ints on failure
            printf("stat() of directory %s failed with exit code: %d\n",
                prefixdir, staterr);
            return(BADSTAT);
        }

    }
    else { // no commandline args given
        printf("A data directory path argument is required.\n");
        return(NOARGS);
    } // end directory arg validation


    SE_FilesLogger mylogger(prefixdir); // create a new logging object

    // Now write some tests using the mylogger object!

    //Everything will fail if you use "\" as the directory argument in the command line
    printf("The logging instance has path prefix: %s\n", mylogger.logpath);
    printf("AccessLog has path prefix: %s\n", mylogger.accessLogFile);

    if (mylogger.logAccess("File Accessed") < 0)      //Testing logAccess
        printf("There was an issue writing to the log file.\n\n");


    //Failing logUserMessage 
    printf("Testing to fail logUserMessage ... ");
    // makes creepy user directory under unix. If a failure, log via accesslog!
    if (mylogger.logUserMessage(" ", " ", "U up?") < 0) //Blank space no good
        printf("logUserMessage failed.\n\n");

    int goodStr = goodString("helloJeffery");
    int badStr = goodString("ba{d");
    int badStr2 = goodString("bad!.");
    int badStr3 = goodString("ba d");
    int badStr4 = goodString("b.a=d");
    int badStr5 = goodString("bad$");       //1 being good and 0 being bad
    printf("\n\nthe results are %i %i %i %i %i %i\n", goodStr, badStr, badStr2, badStr3, badStr4, badStr5);

    SE_User loadTest("jerrymandud", mylogger.logpath);      //Tests using the loadTests only work once.
    loadTest.saveUser();                                    //To test again, change username argument
    loadTest.setPassword("jerrypass");                      //or physically delete the corresponding
    printf("Current: %s\n", loadTest.password);             //user directory and files
    loadTest.loadUser();
    printf("Loaded: %s\n", loadTest.password);

    loadTest.setPassword("jerrypass");
    loadTest.saveUser();
    SE_User loadTestToo(mylogger.logpath);
    printf("Current: %s\n", loadTestToo.username);
    loadTestToo.loadUser("jerrymandud");
    printf("Loaded: %s\n", loadTestToo.username);



    SE_User myUserWO(mylogger.logpath); // create a new user object w/o name

    SE_User myUserW("yournamehere", mylogger.logpath); // create a new user object with name
    //printf("Username saved as: %s\n", myUserW.username);

    int tester = myUserW.saveUser();
    //printf("Test gave back: %i"\n, tester);

    int bad = myUserW.authenticate("defalt");
    int good = myUserW.authenticate("default");
    //printf("success should be %i and failure should be %i\n", good, bad);

    myUserW.listUserNames();


    myUserW.setPassword("gummybear");
    myUserW.changePassword("gummybear", "bummygear");

    myUserW.logError(73, "This is an error");
    myUserW.logError(-2, "Another error!");
    

    //Testing the per second collision
    mylogger.logUserMessage("jerrymanbro", "jerrymanlad", "Hello!");
    mylogger.logUserMessage("jerrymanbro", "jerrymanlad", "Why haven't you responded?!");


    //This is very unpolished code.  I did not put the logError everywhere I could/should have,
    //I didn't test every case.  I was rushed for time at the end so I only made sure everything
    //worked at least once. I also hardly touched my logger class.  There is probably a lot of
    //useless code that I didn't go through and get rid of. My getString method probably gave
    //me the most issues, directly and indirectly.  Probably spent at least 1/3 of the time on that
    //one method troubleshooting.  In the end it won...  I left it in a very lame state.  Sorry for
    //the low quality coding.  I could fix it up with more time spent on the rest of the code.

    return SUCCESS;
}