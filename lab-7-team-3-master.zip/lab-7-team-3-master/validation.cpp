﻿// CMakeProject2.cpp : Defines the entry point for the application.
//

#include "validation.h"
#include <stdio.h>

using namespace std;

double getNum() {
	double jerry;
	printf("Input a number: ");
	while (!scanf("%lf", &jerry)) {
		printf("\nYou must enter a number, please try again:\n");
		while ((getchar()) != '\n');		//scanf does not get rid of the input, need to clear
	}
	return jerry;
};

int getIntNum() {	
	printf("\n\nWARNING: Your input is going to be rounded into an integer\n");
	return getNum() + 0.5;	//Adding 0.5 ensures rounding instead of truncating
};

int getPosNum() {
	printf("\n\nThis number you are about to enter needs to be positive.\n");
	printf("WARNING: Your input is going to be rounded into an integer\n");
	double jerry = getNum();
	while (jerry < 0){
		printf("\nYou must enter a positive number. Please try again:\n");
		jerry = getNum();
	}
	return jerry + 0.5;	//Adding 0.5 ensures rounding instead of truncating
}

char* getString() {
	char jerry[80];

	printf("Input a string: ");
	//while (!scanf("%79s", jerry)) {
	//	printf("\nYou must enter a string, please try again:\n");
	//	while ((getchar()) != '\n');		//scanf does not get rid of the input, need to clear
	//}
	scanf("%79s", jerry);
	//printf("In getString() %s\n", jerry);
	return jerry;
}

int goodString(char* str) {
	char str1[256];
	char* pch;
	sprintf(str1, "a%sa", str);		//Wrap with a's to solve an issue
	//If the string only had an(some) illegal character(s)
	//at the end of the code then it would exit with a count
	//of one because the strtok ignores the separator characters
	//and finds NULL at the end of what it sees as the only string
	pch = strtok(str1, " ,./;:'|]}[{+=)(*&^%$#@!~`?<>\\");
	int count = 0;


	//This separates the given string every time it hits an
	//illegal character and counts the number of times it does
	//(series of adjacent illegal characters are counted as one)
	while (pch != NULL)	{
		pch = strtok(NULL, " ,./;:'|]}[{+=)(*&^%$#@!~`?<>\\");
		count++;
	}
	if (count == 1)
		return 1;
	else
		return 0;
}
