
/*
 * Method definitions for file-based logging class SE_FilesLogger
 */

#include <string>
#include <fstream>
#include <sys/stat.h>
#include "SE_FilesLogger.h"

using namespace std;

 /****************************************
  * Class constructor requires path
  ****************************************/
SE_FilesLogger::SE_FilesLogger(char* pathprefix) {

	strncpy(logpath, pathprefix, sizeof(logpath));

	sprintf(accessLogFile, "%s%c%s", pathprefix, DIRSEP, "accessLog.txt");

	sprintf(errorLogFile, "%s%c%s", pathprefix, DIRSEP, "errorLog.txt");

} // end SE_FilesLogger constructor


/****************************************
 * Log given message to file this->pathprefix/accessLog.txt
 ****************************************/
int SE_FilesLogger::SE_Log(char* message, int a) {
	int X = 0;
	time_t tim;
	struct tm* det1;
	char time_buff[100];
	time(&tim);
	det1 = localtime(&tim);
	strftime(time_buff, sizeof(time_buff), "%Y-%m-%d_%H:%M:%S", det1);
	if (a) {	//accessLog
		//Logs access in pwd\accessLog.txt
		FILE* logFile;
		logFile = fopen(accessLogFile, "a");
		if (logFile == NULL) {
			SE_FilesLogger::SE_Log("Access log could not be accessed", 0);
			fclose(logFile);
			return -1;
		}
		if (fprintf(logFile, "%s   Access:  %s\n\n", time_buff, message) < 0) {
			SE_FilesLogger::SE_Log("Access log could not be written to", 0);
			fclose(logFile);
			return -1;
		}

		fclose(logFile);
	}
	else {		//errorLog
		//Logs errors in pwd\errorLog.txt
		//Notes time and error desc
		FILE* logFile;
		logFile = fopen(errorLogFile, "a");
		if (logFile == NULL) {
			printf("Error log could not open\n");
			fclose(logFile);
			return -1;
		}
		if (fprintf(logFile, "%s   Error:  %s\n\n", time_buff, message) < 0){
			printf("Error log could not be written to\n");
			fclose(logFile);
			return -1;
		}

		fclose(logFile);
	}
	return 0;
} // end SE_LogAccess()

int SE_FilesLogger::SE_LogUserMessage(char *destinationuser, char* sendinguser, char* message)
{
	char messageDir[256];
	char destinationDir[256];
	struct stat statM;
	struct stat statD;
	struct stat statF;
	int staterr_message = 0;
	int staterr_destination = 0;
	int staterr_file = 0;
	int dir_status_m = 0;
	int dir_status_d = 0;

	//Create the paths that need to be checked
	sprintf(messageDir, "%s%c%s", logpath, DIRSEP, "Messages");
	sprintf(destinationDir, "%s%c%s", messageDir, DIRSEP, destinationuser);
	//printf("path: %s", destinationDir);
	//build logpath/messages
	staterr_message = stat(messageDir, &statM); // If we can stat it, it exists

	if (staterr_message) { // Build the message directory if it doesn't exist
		dir_status_m = mkdir(messageDir, 0700); // <-- POSIX requires 2 args, I fixed for win32 w/ macro
		if (dir_status_m < 0)
			printf("Building the message directory failed.\n");
	}	

	//build logpath/messages/destinationuser
	staterr_destination = stat(destinationDir, &statD); // If we can stat it, it exists

	if (staterr_destination) { // Complain if it doesn't exist
		printf("Destination user does not exist\n");
	}

	char message_send[256];
	char destination[256];
	int X = 0;
	time_t tim;
	struct tm* det1;
	char time_buff[100];
	time(&tim);
	det1 = localtime(&tim);
	strftime(time_buff, sizeof(time_buff), "%Y%m%d_%H%M%S", det1);
	//printf("Date Format: %s\n", time_buff);

	//Check if the file number is already written to (per sec collision prevention)
	while (!staterr_file) { // Increment X value if already exists
		sprintf(destination, "%s%c%s_%d", destinationDir, DIRSEP, time_buff, X);
		staterr_file = stat(destination, &statF);
		X += 1;
	}

	sprintf(message_send, "from %s :\n%s\0", sendinguser, message);

	FILE* messageFile;	//File open, write, close
	messageFile = fopen(destination, "a");
	if (messageFile == NULL)
		return(-1);
	if (fprintf(messageFile, "%s\n\n", message_send) < 0)
		return(-2);

	fclose(messageFile);

	return(0);
}
