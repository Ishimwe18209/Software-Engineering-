#include <sys/stat.h>
#include <fstream>
#include <filesystem>
#include <string>
#include <iostream>

#include "SE_User.h"
#include "SE_FilesLogger.h"
// Collab with Hwang, Park, Ritter, Feldmann-DeMello, Barnes
using namespace std;

SE_User::SE_User(char* prefix_to_messagesdir, char* validin) {
	strncpy(prefixmsgdir, prefix_to_messagesdir, sizeof(prefixmsgdir));
	sprintf(username, "%s", validin);	
	sprintf(messageDirectory, "%s%c%s", prefixmsgdir, DIRSEP, "Messages");
	sprintf(userDirectory, "%s%c%s", messageDirectory, DIRSEP, username);
	sprintf(filePath, "%s%c%s", userDirectory, DIRSEP, fileName);
}

int SE_User::listUserNames() {
	DIR* dir;
	struct dirent* ent;
	if ((dir = opendir(messageDirectory)) != NULL) {
		/* print all the files and directories within directory */
		while ((ent = readdir(dir)) != NULL) {
			if ((strcmp(ent->d_name, ".") == 0) || (strcmp(ent->d_name, "..")) == 0) {
				//ignore
			}
			else {
				printf("%s\n", ent->d_name);
			}
		}
		closedir(dir);
		return 0;
	}
	else {
		/* could not open directory */
		
		return -1;
	}
}
int SE_User::createUser() { // Must be used BEFORE listusernames() method	
	
	struct stat dirstats;
	int staterr = 0;
	staterr = stat(userDirectory, &dirstats);
	if (!staterr) {
		return 1;
	}

	else if (!fail) {
		//logError("Username unable to be used");
		return -1;
	}
	else {
		return 0;
	}
}

int SE_User::saveUser() {
	struct stat statM;
	struct stat statD;
	struct stat statF;
	int staterr_message = 0;
	int staterr_dir = 0;
	int staterr_file = 0;
	int dir_status_m = 0;
	int dir_status_d = 0;
	int dir_status_f = 0;


	staterr_message = stat(messageDirectory, &statM); // If we can stat it, it exists

	if (staterr_message) { // Build the message directory if it doesn't exist
		dir_status_m = mkdir(messageDirectory, 0700); // <-- POSIX requires 2 args
		if (dir_status_m < 0) {
			//Unable to build message directory
			return -4;
		}
	}
	staterr_dir = stat(userDirectory, &statD); // If we can stat it, it exists

	if (staterr_dir) { // Build the  user directory if it doesn't exist
		dir_status_d = mkdir(userDirectory, 0700); // same as above
		if (dir_status_d < 0) {
			//Unable to build user directory
			return -3;
		}
	}
	char fileContents[256] = "default";
	//sprintf(fileContents, "%s %s %s %s %s %s", "Username", username, "Shortname", shortname, "Password", password);
	sprintf(fileContents, "%s %s %s %s", "Username", username, "Password", currentpw);
	FILE* messageFile;	//File open, write, close
	messageFile = fopen(filePath, "w");
	if (messageFile == NULL) {
		//unable to open to file
		fclose(messageFile);
		return -2;
	}
	if (fprintf(messageFile, "%s\n\n", fileContents) < 0) {
		//unable to write to file
		fclose(messageFile);
		return -1;
	}
	fclose(messageFile);

	return 0;			//Everything works
}

int SE_User::setPassword(char* newpw) {
	char* newout = newpw;
	if (currentpw) {
		currentpw = newpw;
		char output[128];
		sprintf(output, "%s %s", "Password has been set to", newpw);
		return 0;
	}

	else {
		//Password is already set
		return -1;
	}
}

int SE_User::changePassword(char* oldpw,char* newpw) {
	const char* verify = currentpw;
	const char* verify1 = oldpw;
	
	if (strcmp(verify1,verify) == 0) {
		currentpw = newpw;		
		char output[128];  
		sprintf(output, "%s %s", "Password has been changed to", newpw);		
		return 0;
	}
	else {
		//Password does not match
		return -1;
	}
		
}

int SE_User::authenticate(const char* pw) {
	const char* verify = currentpw;
	
	if (strcmp(pw,verify)== 0) {
		//Authenticated
		return 0;
	}
	else {
		//Unable to authenticate
		return 1;
	}
	
}
int  SE_User::loadUser() {
	//load user if username is in file system
	//check null, then check in system
	if (username == NULL) {
		//username has not been set
		return -1;
	}
	else {
		struct stat statF;
		int staterr_file = 0;

		staterr_file = stat(filePath, &statF);

		if (staterr_file == 0) {
			char un[256];
			//char sn[256];
			char pw[256];
			char blank[20];
			FILE* userFile;	//File open, write, close
			userFile = fopen(filePath, "r+");
			if (userFile == NULL) {
				//couldnt open userFile.txt
				return -3;
			}
			fscanf(userFile, "%s", blank);	//clear the first string which is "Username"
			fscanf(userFile, "%s", un);		//second string is the actual username
			//fscanf(userFile, "%s", blank);	//clear the first string which is "Shortname"
			//fscanf(userFile, "%s", sn);		//second string is the actual shortname
			fscanf(userFile, "%s", blank);	//clear the first string which is "Password"
			fscanf(userFile, "%s", pw);		//second string is the actual password

			fclose(userFile);

			sprintf(username, "%s", un);
			//sprintf(shortname, "%s", sn);
			
			strncpy(loadedpw, pw, sizeof(loadedpw)); // Workaround created due to earlier memory error
			currentpw = loadedpw;
			sprintf(userDirectory, "%s%c%s", messageDirectory, DIRSEP, username);
			//sprintf(userDirectory, "%s%c%s", messageDirectory, DIRSEP, shortname);
			sprintf(filePath, "%s%c%s", userDirectory, DIRSEP, fileName);
		}
		else {
			//userFile does not exist
			return -2;
		}
	}


	return 0;
}

int SE_User::loadUser(char* un) {
	int taken = 0;
	char uDir[256];
	char shn[32];

	strncpy(shn, un, 8);
	shn[8] = '\0';
	sprintf(uDir, "%s%c%s", messageDirectory, DIRSEP, shn);
	struct stat statD;
	int staterr_dir = 0;

	staterr_dir = stat(uDir, &statD);

	if (staterr_dir == 0) {
		taken = 1;
	}
	if (taken) {
		struct stat statF;
		int staterr_file = 0;
		char fPath[256];

		sprintf(fPath, "%s%c%s", uDir, DIRSEP, fileName);
		staterr_file = stat(fPath, &statF);

		if (staterr_file == 0) {
			char un[256];
			char sn[256];
			char pw[256];
			char blank[20];
			FILE* userFile;	//File open, write, close
			userFile = fopen(fPath, "r+");
			if (userFile == NULL) {
				//Can't open userFile.txt
				return -3;
			}
			fscanf(userFile, "%s", blank);	//clear the first string which is "Username"
			fscanf(userFile, "%s", un);		//second string is the actual username
			//fscanf(userFile, "%s", blank);	//clear the first string which is "Shortname"
			//fscanf(userFile, "%s", sn);		//second string is the actual shortname
			fscanf(userFile, "%s", blank);	//clear the first string which is "Password"
			fscanf(userFile, "%s", pw);		//second string is the actual password

			fclose(userFile);

			sprintf(username, "%s", un);
			//sprintf(shortname, "%s", sn);
			sprintf(currentpw, "%s", pw);
			//sprintf(userDirectory, "%s%c%s", messageDirectory, DIRSEP, shortname);
			sprintf(userDirectory, "%s%c%s", messageDirectory, DIRSEP, username);
			sprintf(filePath, "%s%c%s", userDirectory, DIRSEP, fileName);
		}
		else {
			//userFile does not exist
			return -2;
		}
	}
	else {
		//User does not exist
		return -1;
	}
	return 0;
}

int SE_User::listMessages() {

	DIR* dir;
	struct dirent* ent;
	if ((dir = opendir(userDirectory)) != NULL) {
		/* print all the files and directories within directory */
		printf("\n%s\n", "  ---  Inbox  --- ");
		while ((ent = readdir(dir)) != NULL) {
			if ((strcmp(ent->d_name, ".")==0) || (strcmp(ent->d_name, ".."))==0) {
				//ignore
			}
			else if (strcmp(ent->d_name, fileName)==0) {
				//ignore
			}
			else {

				struct stat statF;
				int staterr_file = 0;
				char fPath[256];

				sprintf(fPath, "%s%c%s", userDirectory, DIRSEP, ent->d_name);
				staterr_file = stat(fPath, &statF);

				if (staterr_file == 0) {
					char un[256];
					char blank[20];
					FILE* userFile;	//File open, write, close
					userFile = fopen(fPath, "r+");
					if (userFile == NULL) {
						//Couldn't open userFile.txt
						return -2;
					}
					fscanf(userFile, "%s", blank);	//clears the "from"
					fscanf(userFile, "%s", un);		//second string is the actual username

					fclose(userFile);

					printf("Message from %s\n", un);
				}
				else {
					//Could not open a directory
					return -1;
				}
			}
		}
		closedir(dir);
		return 0;
	}
	else {
		/* could not open directory */
		return -1;
	}
	return 0;
}

int SE_User::readMessage(char* fromUser) {
	int messageNum = 1;
	DIR* dir;
	struct dirent* ent;
	if ((dir = opendir(userDirectory)) != NULL) {
		/* print all the files and directories within directory */
		while ((ent = readdir(dir)) != NULL) {
			if ((strcmp(ent->d_name, ".") == 0) || (strcmp(ent->d_name, "..")) == 0) {
				//ignore
			}
			else if (strcmp(ent->d_name, fileName) == 0) {
				//ignore
			}
			else {

				struct stat statF;
				int staterr_file = 0;
				char fPath[256];

				sprintf(fPath, "%s%c%s", userDirectory, DIRSEP, ent->d_name);
				staterr_file = stat(fPath, &statF);

				if (staterr_file == 0) {
					char un[256];
					char blank[20];
					FILE* userFile;	//File open, write, close
					userFile = fopen(fPath, "r+");
					if (userFile == NULL) {
						//Can't open userFile.txt
						return -2;
					}
					fscanf(userFile, "%s", blank);	//clears the "from"
					fscanf(userFile, "%s", un);		//second string is the actual username
					
					if (strcmp(un, fromUser) == 0) {
						printf("~ Message %i ~", messageNum);
						messageNum++;
						rewind(userFile);
						char str[100];
						while (fgets(str, 100, userFile) != NULL) {
							printf("%s\n", str);
						}
					}
					else {
						//ignore
					}
					fclose(userFile);
				}
				else {
					//Could not open a directory
					return -1;
				}
			}
		}
		closedir(dir);
		return 0;
	}
	else {
		/* could not open directory */

		return -1;
	}
	return 0;
}

