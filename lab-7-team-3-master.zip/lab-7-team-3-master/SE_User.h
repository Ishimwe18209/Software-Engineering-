#pragma once
#include "crossplatformhooks.h"
#include "SE_FilesLogger.h"

class SE_User {

public:
	char username[64];
	char prefixmsgdir[64];
	char* currentpw;
	char loadedpw[64];
	char path[64];
	char messageDirectory[256];
	char userDirectory[256];
	char filePath[256];
	char* fileName = "userFile.txt";
	bool fail;

	SE_User(char* prefix_to_messagesdir, char* validin); //Constructor with username

	int listUserNames(); //returns names of known users by querying the
						//filesystem for existing user directories with user object files

	int createUser(); //succeeds if new user message directory
												 //AND user's disk file does not exist, and ONLY IF \"newname\"
												 //passes input validation.Method may take a validated
												 //string argument OR use the username value set by the
												 //constructor.Or BOTH(called "overloading").Does NOT
												 //modify the filesysem(see saveUser() below)

	int saveUser(); //writes user info to disk. Creates directory if
					//necessary.When you have this working, remove user - dir
					//creation from your Logger class if you implemented it
					//there.This will prevent storing of messages sent to
					//non - existant users.

	int setPassword(char* newpw); // sets new password if no password is set
							      // yet

	int changePassword(char* oldpw, char* newpw); // changes password to newpw if
												  // oldpw matches existing password

	int authenticate(const char* pw);	  // authenticates a user with pw.
										  // Validates the supplied password argument against the password
										  // stored on the user object(via encryption or hash if you have
										  // chose not to do so).Returns success or faiure.

	int loadUser(char* un);				// loads the file from disk if username has already
												// been set on the object, if it exists in the filesystem.

	int loadUser();

	int listMessages();

	int readMessage(char* fromUser);

private:

};