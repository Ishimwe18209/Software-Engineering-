#pragma once
#include <filesystem>
#include <fstream>
#include <string>
#include <iostream>
#include <ctime>

#include "crossplatformhooks.h"
#include "SE_User.h"
#include "validation.h"

#define SUCCESS  0
#define NOARGS  -1
#define BADSTAT -2

using namespace std;

bool backToMenu(char* userin) {
	if (!strcmp(userin, "$")) {
		cout << "Going Back! \n";
		return 1;
	}
	else
		return 0;
}