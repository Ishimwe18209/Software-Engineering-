﻿// CMakeProject2.h : Include file for standard system include files,
// or project specific include files.


#include <iostream>
#include <string.h>

// TODO: Reference additional headers your program requires here.
double getNum();
int getIntNum();
int getPosNum();
char* getString();
int goodString(char* str);