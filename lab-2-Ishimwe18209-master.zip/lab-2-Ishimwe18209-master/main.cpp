#include "SE-Lab2.h"
#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
  // mass = 3kg, velovity = 4m/s^2
  double a = KineticEnergy(3, 4);

  // mass = 0.5kg, velovity = 0.5m/s^2 , test a function with a decimal numbers
  double b = KineticEnergy(0.5, 0.5);

  // mass = 1500kg, velovity = 1500m/s^2
  double c = KineticEnergy(1500, 1500);

 // FV = 1500, r= 0.05, T= 2 years, m= 15
  double d = presentValue(1500, 0.05, 2, 15);

   // FV = 0, r= 0.05, T= 1 years, m= 10
  double e = presentValue(0, 0.05, 1, 10);
  
  // FV = 75, r= 23 which is <1(error), T= 15 years, m= 20
  // test a function with r less that 1
  double f = presentValue(75, 23, 15, 20);

	if (f < 0) {
	  cout << " interest rate is out of bounds. r must be between 0 and 1";
	}
	cout << "The kinetic energy is " << a << "\n";
	cout << "The Kinetic energy is " << b << "\n";
	cout << "The Kinetic energy is " << c << "\n";
	
	cout << "The presentValue is " << d << "\n";
	cout << "The presentValue is " << e << "\n";
	cout << "The presentValue is " << f << "\n";

	return 0;
}

// I acknowledge getting help from 2/c  Zachary Barnes to debug my code
