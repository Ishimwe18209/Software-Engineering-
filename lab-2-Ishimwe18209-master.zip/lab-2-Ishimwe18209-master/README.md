# Software Engineering Spring 2021 - Lab 2

This lab will focus on the following areas of software development:
- Use of function definition and implementation files
- Creating functions
- Leveraging build systems
- Adding code files to an existing project
- Working with a version control system (Github)

## Functions
Functions are re-usable chunks of code that break a program down into smaller pieces.
This is in contrast to procedural code which may be executed in order from a call to main() for example. Designing functions properly (data types, # of arguments, return type, etc) is critical to program function and stability. In TOOP you were given "problem statements" with a full design to implement. In real software development scenarios, YOU as the software engineer perform that design! To complete this lab, follow the below points:

#### 1. Review the function tutorial from [cplusplus.com](https://cplusplus.com/doc/tutorial/functions/).
There are design considerations that software engineers need to take into account when creating functions such as:
- What are the correct data types to use?
- Are function arguments passed by value or reference?
- What error conditions can occur and how are they handled?
- What does the function need to return to be useful in the context of the overall program?

#### 2. Use the knowledge you gained from Lab1 to clone this repository using Visual Studio.

#### 3. Using the provided source and header file (.cpp and .h) in the repo folder tree:<br>
**Graded Items:**
- Create a function called **kineticEnergy()** that implements the formula for the same. **[2.5 points]**<br>
  ![Image of kinetic energy](https://study.com/cimages/multimages/16/8dc35179-4279-45a1-a0d5-6f582ebd4df1_kinetic_energy_definition.png)
- Create a function called **presentValue()** that implements the formula for the same. **[2.5 points]**<br>
  ![Image of present value formula](https://financetrain.com/wp-content/uploads/pv1.gif)

## Building Software
Now that you have written your functions, the question is how to you run the code? How do you test the code? Up to this point in your academic experience, one of your source files likely included main(). Most IDE's are good at finding main() in your code, and compiling the other project files automatically for you to create and run an executable. The complexity of today's software doesn't translate well to this approach. Why do you think this might be the case?

Modern software development practices use [build automation](https://en.wikipedia.org/wiki/Build_automation) to perform a wide range of software engineering tasks automatically. Take a moment to investigate a couple of the utilities listed in the previous link.

There are many considerations when deciding what build automation utilities to use such as, which programming language(s) are in use, how the software is designed (architecture), and what OS's the software is being deployed to. For instance, if the environment is purely Microsoft Windows or Linux, using [msbuild](https://docs.microsoft.com/en-us/visualstudio/msbuild/msbuild?view=vs-2019) or [Make](https://www.gnu.org/software/make/) would be a great options respectively. What if there is a mixed environment that requires multiple configurations? In this case, the use of a cross platform tool is in order and this lab will use [CMAKE](https://cmake.org/). CMake is a build automation utility that creates platform specific project files (visual studio, eclipse, make, and others) that are then used to build the program. Why you ask? Flexibility of course! Your instructors can use whichever OS they prefer to develop code content, you can run the code on your windows laptop using Visual Studio, and the lab can leverage backend github functionality that runs Ubuntu Linux.

**Graded Items:**
#### 1. Review the [Microsoft Visual Studio 2019 documention](https://docs.microsoft.com/en-us/cpp/build/cmake-projects-in-visual-studio?view=msvc-160#ide-integration) for [building CMake projects](https://docs.microsoft.com/en-us/cpp/build/cmake-projects-in-visual-studio?view=msvc-160#building-cmake-projects) and [editing CMakeLists.txt files](https://docs.microsoft.com/en-us/cpp/build/cmake-projects-in-visual-studio?view=msvc-160#editing-cmakeliststxt-files). Reading some elements of the official [CMake Tutorial](https://cmake.org/cmake/help/latest/guide/tutorial/index.html#guide:CMake%20Tutorial) may also be helpful.
#### 2. Add a main.cpp file to your project folder by right-clicking on the solution explorer window and selecting "Add" -> "New File" **[1 point]**
#### 3. Using the documentation you reviewed and your newly created .cpp file, make the needed changes in the repo so that the CMake project builds. **[1 point]**
#### 4. Test your functions: write three function calls for each function (total of 6), that use different argument values. Your goal is to think about what combinations of values may or may not be handled properly by the code you wrote. Include a code comment above each function call with a short description (e.g. "Test function call with a NULL value"). **[.5 points each]**

**Extra fun (non-graded)**
* Click on the "Actions" tab of your repo and review the suggested "worflows". Click the workflow "CMake based projects" and review the .yml template that github presents you with. See if you can get a working build script OR examine the commands that the script is using with CMake to learn more about the build process.
* Clone your repo to a Linux machine/VM and try building your code. What build files can you generate? Try building project files for a supported IDE.
